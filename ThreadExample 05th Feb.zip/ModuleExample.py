import math

print(math.pi)
print(math.sqrt(9))
print(math.pow(2,3))
print(math.factorial(6))



#
import random

print(random.randint(1,10))
print(random.random()*100)


