#Tuple
t = ('mon','tue','wed','thu','fri')
day = input('enter day name :')

if day in t:
     print('week days ')
else:
     print('week end ')


#Dict
mydata = {1:'one','a':'alpha','d':100,101:[10,'raman','male']}
print(mydata)

key = input('etner key to search value :')

print(mydata[key])

##add new key and value
mydata['m']='motro...'
print(mydata)

mydata['a']='motro...123'
print(mydata)


##global and local variable
c = 0 #global variable can be access anywhere /any function 
 
def add(a,b):
     c =a+b
     return c 


def show(c):
     print(c)


o = add(11,2)
show(o)



     




     
