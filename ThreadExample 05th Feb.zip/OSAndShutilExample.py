
import os
import shutil

src =r'C:\Users\vkumar15\Desktop\PAF'

out = os.listdir(src)
print(out)
print(type(out))

for f in out:
     #print(f)
     #read all text file
     if f.endswith('.txt'):
          print(src+'\\'+f)
          #o = open(src+'\\'+f,'r')
          #print (o.readlines())
          shutil.move(src+'\\'+f,r'C:\Users\vkumar15\Desktop')
          
          
          
          
     
     
     



