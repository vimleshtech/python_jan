'''
Thread : is process or task(every program or applicaiton is itself one process/task)
Multi Threading: Multiple process   

'''
import time
import threading

l = time.localtime()
print(l)
print(l.tm_year)
print(l.tm_mon)


def task1():
     for i in range(1,5):
          print(i)
          #time.sleep(1) # delay

def task2():
     for j in range(11,15):
          print(j)
          #time.sleep(1)
          
#task1()
#task2()
p1 = threading.Thread(target= task1,name='process1')
p2 = threading.Thread(target= task2,name='process2')

p1.start()
p2.start()


     




