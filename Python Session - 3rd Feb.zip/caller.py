
#from child import tax 
import child 


t = child.tax()
t.add(11,433)
t.gst(1200)
t.it(1300000)


