class compute:
    def add(a,b,c):
        d =b+c 
        print(d)

    def mul(a,b,c):
        m = b*c
        print(m)

        