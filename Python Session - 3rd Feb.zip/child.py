#import parent 
from parent import compute 

class tax(compute):

    def it(a,sal):
        
        if sal<=500000:
            tax = 0 
        elif sal<1000000:
            tax = sal*.10 
        else:
            tax = sal*.30 

        net = sal-tax 
        print('tax = ',tax) 
        print('net pay = ',net) 
    def gst(a,amt):
        total = 0
        tax = 0
        if amt>1000:
            tax = amt*.18
        else:
            tax = amt*.05

        total = amt+tax 
        print('total amt = ',total)



