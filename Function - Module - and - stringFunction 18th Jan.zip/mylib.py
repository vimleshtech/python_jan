#no argument no return 
def wel():
     print('welcome to fun world... this file contians following functions \n i. wel ii. getdata iii. add iv. sub ')


#no argument with return
def getdata():
     a =  int(input('enter data :'))
     b =  int(input('enter data :'))

     return a,b

#argument with no return
def add(a,b):
     c =a+b
     print(c)
     
#argument with return
def mul(x,y):
     z =x*y
     return z
