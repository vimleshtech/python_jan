#
import mylib
mylib.add(11,22)
mylib.wel()

##or
from mylib import add,wel
add(11,3)
wel()

#or
from mylib import *
add(11,3)


#or
import mylib as m
m.add(11,)
