#no argument no return 
def wel():
     print('welcome to fun world... this file contians following functions \n i. wel ii. getdata iii. add iv. sub ')


#no argument with return
def getdata():
     a =  int(input('enter data :'))
     b =  int(input('enter data :'))

     return a,b

#argument with no return
def add(a,b):
     c =a+b
     print(c)
     
#argument with return
def mul(x,y):
     z =x*y
     return z
#function with default argument
def addNum(a,b,c=0,d=0,e=0):
     x = a+b+c+d+e
     print(x)

#function with dynamic argument
def mul2(*a):
     o =1
     for x in a:
          o *= x

          
     
     print(o)

     #or
     o =1
     for i in range(0,len(a)):
         o *= a[i]  # o = o* a[i]

     print(o)
     
#recusive function
def fact(n):
     if n == 1:
          return n
     else:
          return n*fact(n-1) #5*4 * 3 *2 
     

#or
def fact2(x):
     i =1
     for j in range(2,x+1):
          i *= j

     print(i)
     
#invoke or call to function
wel()
wel()
##example
x,y =11,22
x=y =11

m,n = getdata()
print(m+n)

add(11,22)
add(67666,333)

o = mul(11,2)
print(o)

addNum(11,2)
addNum(11,2,3)
addNum(11,2,3,4)
addNum(11,2,32232,333,44)
     

mul2(1,2)
mul2(1,2,333333,4444,3333,2222,3333,4333,2222,222,2)


o = fact(5)
print(o)


     
