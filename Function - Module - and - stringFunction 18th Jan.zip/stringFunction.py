a ="this is "

if a.startswith('th'):
     print('first char is t')
else:
     print('no match')
     

##
a ="sjhsjgsjsshs@gmail.com"

if a.endswith("gmail.com"):
     print('gmail account ')
else:
     print('other account')
     
