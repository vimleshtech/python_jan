a ="this is python code. python is open source..."
count = a.count(' ')
print(count)

#or   1
l = len(a) - len(a.replace(' ',''))
print(l)





