import pandas as pd

df = pd.read_csv(r'E:\Sandbox\Python\emp.csv')
print(df)

#read one column
print(df['name'])

#columns
print(df.columns)

#return top given rows
print(df.head(2))

#return buttom given rows
print(df.tail(3))

#return shpae(dimenssion)
print(df.shape)


#########group by
print(df.groupby('gender').count())
print(df.groupby('gender').size())
print(df.groupby('gender').max())
print(df.groupby('gender').min())
print(df.groupby('gender').sum()['salary'])


#sort
print(df.sort_values('salary',ascending=True))
print(df.sort_values('salary',ascending=False))      








