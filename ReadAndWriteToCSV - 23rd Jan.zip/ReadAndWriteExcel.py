import xlrd

book  = xlrd.open_workbook(r'E:\Sandbox\Python\Data.xlsx')
#print(book)

sheet = book.sheet_by_index(0)
#print(sheet)

rc = sheet.nrows
print(rc)

cc = sheet.ncols
print(cc)


#val = sheet.cell_value(0,0) #first row and first col
#print(val)

for i in range(0,rc):
    col1 = sheet.cell_value(i,0)
    col2 = sheet.cell_value(i,1)
    col3 = sheet.cell_value(i,2)
    col4 = sheet.cell_value(i,3)
    print(col1,'\t',col2,'\t',col3,'\t',col4)
    
##write to excel
import xlwt 

  
# Workbook is created 
wb = xlwt.Workbook() 
  
# add_sheet is used to create sheet. 
sheet1 = wb.add_sheet('users')   
sheet1.write(0, 0, 'test1') 

wb.save('example.xls') 




