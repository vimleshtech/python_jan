import os
import shutil 

path =r'E:\Sandbox\copy\learning99'
files = os.listdir(path)
#print(files)

for f in files:
    #print(f)
    if f.endswith('.txt'):
        print(f)
        fo = open(path+'\\'+f,'r')
        print(fo.read())
        fo.close()
        
        #copy, move files and folder
        shutil.move(path+'\\'+f,r"E:\Sandbox\Python")        





        
    



