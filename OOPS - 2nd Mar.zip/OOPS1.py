class emp:

     #in every function we need to receive at least one argument which will take ref of object
     def newemp(s): #s is an reference of object

          s.eid  = input('enter eid :')
          s.ename  = input('enter name:')
          s.sal  =  int(input('enter sal:'))
          
     def show(s):
          print('eid is ',s.eid)
          print('name is ',s.ename)
          print('monthly sal is ',s.msal)
          print('yearly sal  is ',s.ysal)

     def compute(a):
          a.hra = a.sal *.18
          a.da = a.sal *.10

          a.msal = a.sal+a.hra+a.da
          a.ysal = a.msal * 12
          
                           
          
          




#create object
o = emp()
print(o)
#call to function
o.newemp()
o.compute()
o.show()


