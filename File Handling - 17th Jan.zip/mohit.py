f = open(r'C:\Users\vkumar15\Desktop\mohittest.txt','r')
'''
for x in range(1,5):
     w=input('Enter data:')
     f.write(w+'\n')

c=input('Enter the data:')
f.write(c)
print('data is saved')
'''
d=f.read()
print(d)
'''
n=input('Enter the word you want to search:')

for r in d:
     w=r.split(' ')
     
     for c in w:          
          if c.replace('\n','')==n:
               print('Word is Found')
               break
          
     
     for z in y:
          if y==b:
               print('Word is Found')
          else:
               print('Word not found')
     

#f.close()
'''


y=len(d)-len(d.replace(' ',''))
                  
print('Number of spaces:',y)
                  
'''
     for c in w:          
          if c.replace('\n','')==n:
               print('Word is Found')
               break
'''
