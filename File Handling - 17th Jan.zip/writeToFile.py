
#create new file if file is not exist
f = open(r'C:\Users\vkumar15\Desktop\out.txt','a')

for x in range(1,5):

     w = input('enter data :')     
     f.write(w+'\n')

print('data is saved')
f.close()



#wap to check given word is exist in file or not
#wap to get count of space from file
#wap to get sum of salary by gender
'''
input.txt
---
id,name,gender,salary
1,raman,male,3232
2,jatin,male,3333
3,monika,female,43443


out:
male 2 65....
female 1 433443
'''
