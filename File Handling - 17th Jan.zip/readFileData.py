f = open(r'C:\Users\vkumar15\Desktop\------------- Python Session  14th Jan ------- .txt','r')
#print(f)

#show all content 
#print(f.read())

#show first line content
#print(f.readline())
#print(f.readline())
#print(f.readline())


#read all lines and store on list
d = f.readlines()
print(d)

print('no of rows ',len(d))

#word count
wc = 0

#get particular word count
pwc = 0

for r in d:
     #print(r)
     w = r.split(' ')
     wc = wc+ len(w)
     for c in w:
          if c =='is':
               pwc = pwc+1
               
print(wc)
print(pwc)


     
      


