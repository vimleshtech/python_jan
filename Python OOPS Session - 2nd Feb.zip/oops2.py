class employee:

    def newEmp(s):
        s.eid = int(input('enter eid :'))
        s.ename = input('enter name :')
        s.ebasic = int(input('enter basic sal :'))
        
    def compute(a):
        #a.newEmp()
        a.hra = a.ebasic*.50
        a.da = a.ebasic*.50
        a.monthly = a.ebasic+a.hra+a.da 

    def show(c):
        #c.compute()
        print(c.eid)
        print(c.ename)
        print(c.monthly)
        

e =employee()
e.newEmp()
e.compute()
e.show()