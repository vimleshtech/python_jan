class example:
    def add(self):
        print(self)
        self.a =11
        self.b =12

        print(self.a+self.b)
    def sub(s):
        print('sub function')
        print(s.a-s.b)
    def mul(a):
        print('mul function ')
        print(a.a-a.b)
#create an object of class
o = example()
print(o)
o.sub()
o.add()

o.mul()


