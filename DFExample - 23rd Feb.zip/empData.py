import pandas as pd
a = pd.read_csv(r'C:\Users\vkumar15\Desktop\Desktop - Raman\emp.csv')
print(a)


