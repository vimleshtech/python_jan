import pandas as pd

#create emplty dataframe or table
#Example 1
#df = pd.DataFrame()
#print(df)  #no column , no rows/Index



#Example 2 : create dataframe from list
eid  = [1,2,3,4]
ename = ['raman','jatin','monika','ridhi']
gender = ['male','male','female','female']
esal  = [4444,65444,44555,33333]


df = pd.DataFrame(data={'emp_code':eid,'name':ename,'gender':gender,'salary':esal})
print(df)


#operations
print(df.columns)  #RETURN list of columns
print(df.shape)     #return row and col count
print(df.head(n =2)) #return from top
print(df.tail(n =3)) # return from buttom

#read particular column
print(df['name'])

#distribuation / group by
print(df.groupby('gender').size() )
print(df.groupby('gender').sum() )
print(df.groupby('gender').sum()['salary'] )
print(df.groupby('gender').max()['salary'] )
print(df.groupby('gender').min()['salary'] )


#order by
print(df)
print(df.sort_values('salary',ascending=True))
print(df.sort_values('gender',ascending=True))

#show stats
print(df.info())
print(df.describe())






















