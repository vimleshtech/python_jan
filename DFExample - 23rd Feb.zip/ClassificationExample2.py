import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

fruits = pd.read_table(r'C:\Users\vkumar15\Desktop\Desktop - Raman\fruits_data.txt')
print(fruits.head())  #show from top , default 5 rows

print(fruits.shape)

#get unique list
print(fruits.groupby('fruit_name').size())


sns.countplot(fruits['fruit_name'],label="Count")
plt.show()






