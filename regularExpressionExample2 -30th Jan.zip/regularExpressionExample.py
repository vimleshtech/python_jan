'''
Regular Expression:
     re :is inbuilt module
     import re
     Methods:
          match(pattern,string)
          groups()
          group(index)
          search(pattern,string)
          findall(pattern,string)
          etc.
     pattern:
          /d   : digits [0-9]
          /D   : non-digit
          /w   : chars [a-zA-Z]
          /W   : non-chars
          .    : any char
          *    : any no. of times (a*) , (.*)
          ()   : group
          {min len,max len}   : min lenght, max length
          ^    : start with
          $    : end with 

          
'''  
import re

data = input('enter string :')

o = re.match('(.*) is (.*)',data)
#192.168.10.1@azure.com

print(o.groups())
print(o.group(1))
print(o.group(2))

if o:
     print('is present ..')
else:
     print('is not present ..')

#####
email = input('enter email id  :')
o = re.match('@gmail.com',email)
print(o)

#search
o = re.search('@gmail.com',email)
if o:
     print('valid gmail account')
else:
     print('invalid gmail account')


###start with
o = re.search('^a',email)
if o:
     print('start with a')
else:
     print('not start with a')
     
####
data = input('enter data :')
out = re.findall('\d',data)  #sjjkshsj1113331211shhsgss113 :
print(out)








     





     










