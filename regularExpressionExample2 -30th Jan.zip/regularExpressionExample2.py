import re
import os

src =r'C:\Users\vkumar15\Desktop\PAF'
files  = os.listdir(src) #read all files and folder

#print(files)
def filterdata(path):
     #open the .txt file 
     out  = open(src+'\\'+path,'r')

     print('**************file name : ',path,' ***************')
     for line in out.readlines():
          #print(line)
          o = re.search('(.*) is (.*)',line)
          if o:
               print(line)


for f in files:
     #read all .txt files
     if f.endswith('.txt'):
          filterdata(f)
          
          
     


          
     


