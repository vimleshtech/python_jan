#wap to show greater no.
a = int(input('enter data :'))
b = int(input('enter data :'))
c = int(input('enter data :'))

if a>b and a>c:
     print('a is greater')
elif b>a and b>c:
     print('b is greater')
elif c>a and c>b :
     print('c is greater')
elif a ==b and a ==c :
     print('all are equal ')
else:
     print('any two are equal and one is different')

#nested if else /if inside if
if a>b:
     if a>c:
          print('a is gt')
     else:
          print('b is gt')

else:
     if b>c:
          print('b is gt')
     else:
          print('c is gt')

          


          


          
     
     
     
