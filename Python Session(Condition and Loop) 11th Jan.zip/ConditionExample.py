sales =input('enter sale amount :') # default data type is str

sales = int(sales)
#print(type(sales))

tax = 0
#if condition
if sales>1000:
     tax = sales*.18


total = sales+tax
print(total)

#if else
tax = 0
if sales>1000:
     tax = sales*.18 # sales*18/100 
else:
     tax = sales*.10
     
     
total = sales+tax
print(total)     

#if elif elif.....
if sales>1000:
     tax = sales*.18
elif sales>500:
     tax = sales*.10
elif sales>100:
     tax = sales*.05
else:
     tax = 0

total = sales+tax
print(total)     




     




     
     

     
     

