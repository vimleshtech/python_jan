#example -1
a =2
b = a**3
print(b)


#example -2
a =85
b =a/10
print(b)

#example -3
a =85
b =a//10
print(b)

#
a =85
b =a%10
print(b)


