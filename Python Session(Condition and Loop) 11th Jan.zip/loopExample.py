print(1,end='')#don't change the line
print(2)

#while loop

i =1   #init 
while i<10: #condition

     print(i)
     i =i+1 #increment

#print in reverse order
i =10
while i>0:
     print(i)
     i = i-1



#print all odd numbers between 1 to 30
i = 1
while i<=30:
     print(i)
     i =i+2


#wap to print sum of all even and odd nubers between two given range
se =0
so  =0
a  = int(input('enter data :'))
b  = int(input('enter data :'))

while a<=b:
     if a%2 ==0:
          se =se+a
     else:
          so =so+a

     a=a+1

print(se)
print(so)


##for loop
for x in range(1,10,2):  # from 1 to <10, default incrementer is 1
     print(x)



#print in reverse
for x in range(10,0,-1):
     print(x)



#nested loop
#i =1 j = 1 2 3 4
#i =2 j = 1 2 3 4
#i =3 j = 1 2 3 4
#i =4 j = 1 2 3 4     
for i in range(1,10): #for rows 
     
     for j in range(1,9): # cols 
          print(j,end=' ')
     print() #change ghe line



          
     
     


     

     
     


     



          
          








     
     
