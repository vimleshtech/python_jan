import re

'''
s = input('enter string :')

o = re.match("(.*) is (.*)",s)
print(o)
print(o.group())
print(o.groups())

print(o.group(2))

if o:
     print('is is present')
     
else:
     print('is is not present')
     

##check / validte email id
email = input('enter gmail account id :')

v  = re.match('(.*)@gmail.com',email)
if v:
     print('correct gmail account')
else:
     print('incorrect email account')


##start with
d = re.search('^a',email)

if d:
     print('string is starting with a')
else:
     print('not starting with a')

'''

###
data = input('enter data :')

o = re.findall('\d',data)
print(o)


o = re.findall('\w',data)
print(o)





     
     



          

     


     
