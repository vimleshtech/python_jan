#no argument, no return
def wel():
     print('welcome to function world ')
     print('this function is  - no argument, no return')


#no argument with return
def getdata():
     a =int(input('enter data :'))
     b =int(input('enter data :'))
     return a,b

#argument witn no return
def add(a,b):
     c =a+b
     print(c)
     
#argument with return
def sub(a,b):
     x =a-b
     return x

#function with default argument
def addNum(a,b,c=0,d=0):
     o =a+b+c+d
     print(o)
     
#function with dynamic argument
def mul(*a):
     print(a)
     o =1
     for x in a:
          print(x)
          o =o*x

     print(o)
     
          
#rescursive function
def fact(n):
     if n ==1:
          return n
     else:
          return n*fact(n-1) #5* 4 * 3*2*1
     
#lambda expression
y = lambda x:x+1


g = lambda x: x*x*x 




wel()
wel()


x,y = getdata()
print(x+y)

add(11,22)
add(11,220)

o = sub(11,22)
print(o)
add(o,10)


addNum(11,2)
addNum(11,2,3)
addNum(11,2,33,4)


mul(11,22)
mul(11,22,3232322,22222,33232,12111,22)

o = fact(5)
print(o)

#x = y()

#print(x(10))
print(g(7))




