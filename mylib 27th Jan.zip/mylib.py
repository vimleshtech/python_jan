#no argument, no return
def wel():
     print('welcome to function world ')
     print('this function is  - no argument, no return')


#no argument with return
def getdata():
     a =int(input('enter data :'))
     b =int(input('enter data :'))
     return a,b

#argument witn no return
def add(a,b):
     c =a+b
     print(c)
     
#argument with return
def sub(a,b):
     x =a-b
     return x

