
import pandas as pd

#CREATE empty dataframe
d = pd.DataFrame()
print(d)


#convert list to dataframe
cid = [11,222,44,555,666]
name = ['raman','jatin','ayush','monika','ridhi']
hrs = [4,5,3,8,10]
score = [45,58,32,70,91]

d = pd.DataFrame(data={'sid':cid,'name':name,'hrs':hrs,'score':score})
print(d)

print(d.corr())

print(d.drop(['sid'],axis=1).corr())


#o =  d.corr()
#o.to_csv(r'C:\Users\vkumar15\Desktop\corr.csv')


#cars
cc = [1200,1400,1600,1250,2200]
mpg = [20,18,15,19,13]
cars = pd.DataFrame(data={'cc':cc,'mpg':mpg})
print(cars.corr())
























