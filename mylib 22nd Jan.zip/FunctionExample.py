#no argument, no return 
def wel():
     print('welcome to fun world...')


#no argument, with return
def getdata():
     a = int(input('enter data :'))
     b = int(input('enter data :'))

     return a,b

#argument, with no return
def add(a,b):
     c =a+b
     print(c)

#argument, with return
def mul(a,b):
     c =a*b
     return c

#call to function
wel()
wel()

x,y = getdata()
print(x+y)
print(x-y)



a,v = getdata()
print(a*v)

add(a,v)
add(22,55)


o = mul(11,32)
print(o)
add(o,10)







