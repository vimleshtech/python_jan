import mylib
mylib.add(12,3)


#or
from mylib import add,wel
wel()
add(1,2)

#or
from mylib import *
add(1,23)


#or
import mylib as m
m.add(3,3)

