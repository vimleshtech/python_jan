import pandas as pd
import seaborn as sns
import matplotlib.pyplot  as plt
from sklearn.model_selection import train_test_split

import pylab as pl

from pandas.tools.plotting import scatter_matrix
from matplotlib import cm


fruits= pd.read_table(r'C:\Users\vkumar15\Desktop\Desktop - Raman\fruits_data.txt')
print(fruits)

print(fruits.head())
print(fruits.columns)
print(fruits.shape)



#get list of unique value
print(fruits['fruit_name'].unique())

#distribuation
print(fruits.groupby('fruit_name').size())

#plot : plot for freq
#sns.countplot(fruits['fruit_name'],label="Count")
#plt.show()



#Box plot for each numeric variable will give us a clearer idea of the distribution of the input variables
#fruits.drop('fruit_label', axis=1).plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False, figsize=(9,9), title='Box Plot for each input variable')
#plt.savefig(r'C:\Users\vkumar15\Desktop\Desktop - Raman\fruits_box.pdf')
#plt.show()


#hist
#fruits.drop('fruit_label' ,axis=1).hist(bins=30, figsize=(9,9))
#pl.suptitle("Histogram for each numeric input variable")
#plt.savefig('fruits_hist')
#plt.show()

#scatter matrix
feature_names = ['mass', 'width', 'height', 'color_score']
X = fruits[feature_names]
y = fruits['fruit_label']


#cmap = cm.get_cmap('gnuplot')

#scatter = pd.scatter_matrix(X, c = y, marker = 'o', s=40, hist_kwds={'bins':15}, figsize=(9,9), cmap = cmap)
#plt.suptitle('Scatter-matrix for each input variable')
#plt.savefig(r'C:\Users\vkumar15\Desktop\Desktop - Raman\fruits_scatter_matrix.pdf')
#plt.show()


##info
print(fruits.info())
#
print(fruits.describe())

#break split and validation data
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

print(X_train)
print(X_test)
print(y_train)
print(y_test)


#from sklearn.preprocessing import MinMaxScaler
#scaler = MinMaxScaler()
#X_train = scaler.fit_transform(X_train)
#X_test = scaler.transform(X_test)




##
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(X_train, y_train)
#print(logreg.score(X_train, y_train))

print('Accuracy of Logistic regression classifier on training set: {:.2f}'.format(logreg.score(X_train, y_train)))




                                        












