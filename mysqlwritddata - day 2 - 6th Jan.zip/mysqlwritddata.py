import mysql.connector as c

con = c.connect(host='localhost',user='root',password='root',database='mylearning')
#print(con)
cur = con.cursor()
cur.execute("insert into emp(id,name) values(11,'ashish')")

con.commit()

print('data saved ')

