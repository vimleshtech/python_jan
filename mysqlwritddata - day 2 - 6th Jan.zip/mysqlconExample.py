import mysql.connector as c

con = c.connect(host='localhost',user='root',password='root',database='mylearning')
#print(con)
cur = con.cursor()
cur.execute('select * from emp')

#print(cur)
out = cur.fetchall()

'''
print(out)

print(type(out))


print(out[0][0])
print(out[1][1])
print(out[2])
'''
for a in out:
     print(a[0], a[1])
     
     

