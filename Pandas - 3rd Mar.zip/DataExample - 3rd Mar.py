
#go to script folder
#pip install pandas

#import library (inbuilt functions)
import pandas

#load data 
data= pandas.read_table(r'C:\Users\vkumar15\Desktop\emp.csv',sep=',')

#show / print data 
print(data)

#show list of columns
print(data.columns)

#show row numbers 
print(data.index)


#shwo shape (count of row and columns)
print(data.shape)


#show top given no of rows / default is 5
print(data.head()) #default is 5 
print(data.head(2)) #show 2 rows

#show data from tail/buttom
print(data.tail()) #default is 5


#show particular column
print(data['name'])

#sorting / arrange in ascending or decending order
print(data.sort_values('age',ascending=True)) #in ascending
print(data.sort_values('age',ascending=False))  #in descending 


#data distribuation / group by
print(data.groupby('gender').size())
print(data.groupby('age').size())

print(data.groupby('age').max())
print(data.groupby('age').max()['salary'])

print(data.groupby('age').min()['salary'])
print(data.groupby('gender').sum()['salary'])

#show basic stats
print(data.describe())
out =data.describe()

out.to_csv(r'C:\Users\vkumar15\Desktop\output.csv')





















