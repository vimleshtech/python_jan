data =[]

i =1
while i<5:
    d = input('enter data :')
    data.append(d)
    i =i+1


print(data)
