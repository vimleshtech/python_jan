try:
        
    n = int(input('enter data :'))
    d = int(input('enter data :'))

    try:
            
        #div
        if d<0:
            er = ValueError()
            errcode =1
            raise er 
        o =n/d
        print(o)

    except ValueError:
        if errcode==1:            
            print(er)
        if errcode ==2:
            print('aa')
            
    except ZeroDivisionError as e:
        print(er)        
    except:
        print('there is some error')
        
    #sum/add
    print(n+d)
except ValueError as v:
    print(v)
except NameError as n:
    print(n, ' Ticket assign to User 1')
except:
    print('type casting error')

finally:
    print('end of the code ')
    
