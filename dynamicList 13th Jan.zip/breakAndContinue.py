i =1
while i<10:

    if i % 4 ==0:
        break
    
    print(i)
    i =i+1

    
#
i =0
while i<10:
    i =i+1
    if i % 4 ==0:
        continue    
    print(i)
    


    
