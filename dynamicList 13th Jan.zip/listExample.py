data = [111,2222,3333,11,22,34]

print(len(data))
print(max(data))
print(min(data))
print(sum(data))

data.append(12222)
print(data)

data.pop()
print(data)


data.insert(1,300)
print(data)

data.remove(300)
print(data)

data.remove(data[1])
print(data)

#asc
data.sort()
print(data)

#desc
print(data[::-1])
    

data[1:3] = []
print(data)








