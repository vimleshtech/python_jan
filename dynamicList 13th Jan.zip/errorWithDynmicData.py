import time

while True:
    try:
        
        n = int(input('enter data :'))
        d = int(input('enter data :'))
        o =n/d
        print(o)
        
        break#terminate the loop , jump outside from loop 
    except:
        print('try again...')
    
    time.sleep(5)
    
