i =10 #increment
while i<15:
     #print(i)
     #print in same row/line
     print(i,end=',')
     i +=1


#print in reverse order
i =10
while i>0:
     print(i)
     i-=1
     
     
