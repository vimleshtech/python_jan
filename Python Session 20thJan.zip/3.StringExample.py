s = input('enter string data :')#.upper()

#print(s)
#print(s.upper())

ns = s.upper()
print(ns)

#s =s.upper()
#print(s)

###lower
ns = s.lower()
print(ns)

#len
l = len(s)
print(l)

##list
o =list(s)
print(o)

##
ns = s.replace('a','xyz')
print(ns)

##cout
c = s.count("is")
print(c)


#strip
ns = s.strip()  #trim 
print(ns)
print(len(ns))

 
ns = s.lstrip() #remove from left
ns = s.rstrip() # remove from right 

#split
words = s.split('a') #raman sinha = ['r','m','n sinh']
print(words)
words = s.split(' ') # ['raman','sinha']
print(words)

##conditional  string function
d =s
if s.islower():
     print(d, ' is in small case ')
else:
     print(d, ' is not in small case ')


if s.isupper():
     print(d, ' is in upper case ')
else:
     print(d, ' is not in upper case ')





if s.startswith("th"):
     print(d, ' start with th ')
else:
     print(d, ' is not start with th ')


if s.endswith("th"):
     print(d, ' end  with th ')
else:
     print(d, ' is not end with th ')
























