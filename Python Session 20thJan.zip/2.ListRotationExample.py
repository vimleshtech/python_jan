a =[2,3,5,3,21]


ps = int(input('enter position :'))
print(a)
for i in range(0,ps):
     t = a[i]
     a.append(t)

a[0:ps] = []
print(a)
	
